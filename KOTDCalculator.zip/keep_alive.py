#imports Flask which will be used for the webserver and imports a thread to use as a flow of execution the webserver runs on
from flask import Flask
from threading import Thread

#defines an app as a flask app and creates a route for the app
app = Flask('')
@app.route('/')

#defines the main function that'll run as soon as the repl runs
def main():
    return "Your bot is alive!"

#defines what happens when the webserver runs
def run():
    app.run(host="0.0.0.0", port=8080)

#defines the keep alive function that simply starts the webserver
def keep_alive():
  server = Thread(target=run)
  server.start()   
import discord
import os
from discord.ext import commands
from discord.ext.commands import bot
import asyncio
import datetime
import flask
import matplotlib
import scipy
import numpy
import math
#from scipy.stats import binom_test as binomtest
from scipy.stats import binomtest

import keep_alive

critRate = 12.5 #to be updated with a better algorithm later
avgCritDamage = 10 #to be updated with a better algorithm later, along with binom dist calculation (maybe)
WeaponDict = {}
WeaponDict = {
  3 : {"element" : "light","baseDamage" : 1, "minWeakDamage" : 5, "maxWeakDamage" : 13, "avgWeakDamage" : 9 },
  4 : {"element" : "curse","baseDamage" : 1, "minWeakDamage" : 5, "maxWeakDamage" : 13, "avgWeakDamage" : 9 },
  5 : {"element" : "light","baseDamage" : 2, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  6 : {"element" : "dark","baseDamage" : 2, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  7 : {"element" : "lawful","baseDamage" : 3, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  8 : {"element" : "chaos","baseDamage" : 3, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  9 : {"element" : "lawful","baseDamage" : 3, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  10 : {"element" : "dark","baseDamage" : 3, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  11 : {"element" : "order","baseDamage" : 3, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  12 : {"element" : "havoc","baseDamage" : 3, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  13 : {"element" : "curse","baseDamage" : 3, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  14 : {"element" : "almighty","baseDamage" : 3, "minWeakDamage" : 6, "maxWeakDamage" : 14, "avgWeakDamage" : 10 },
  15 : {"element" : "bless","baseDamage" : 4, "minWeakDamage" : 7, "maxWeakDamage" : 15, "avgWeakDamage" : 11 },
  16 : {"element" : "sinful","baseDamage" : 4, "minWeakDamage" : 7, "maxWeakDamage" : 15, "avgWeakDamage" : 11 },
  17 : {"element" : "curse","baseDamage" : 4, "minWeakDamage" : 7, "maxWeakDamage" : 15, "avgWeakDamage" : 11 },
  18 : {"element" : "light","baseDamage" : 4, "minWeakDamage" : 7, "maxWeakDamage" : 15, "avgWeakDamage" : 11 },
  19 : {"element" : "order","baseDamage" : 4, "minWeakDamage" : 7, "maxWeakDamage" : 15, "avgWeakDamage" : 11 },
  20 : {"element" : "almighty","baseDamage" : 5, "minWeakDamage" : 8, "maxWeakDamage" : 15, "avgWeakDamage" : 11.5 },
  21 : {"element" : "bless","baseDamage" : 6, "minWeakDamage" : 13, "maxWeakDamage" : 22, "avgWeakDamage" : 17.5 },
  22 : {"element" : "curse","baseDamage" : 6, "minWeakDamage" : 13, "maxWeakDamage" : 22, "avgWeakDamage" : 17.5 },
  23 : {"element" : "chaos","baseDamage" : 6, "minWeakDamage" : 13, "maxWeakDamage" : 22, "avgWeakDamage" : 17.5 },
  24 : {"element" : "sinful","baseDamage" : 6, "minWeakDamage" : 13, "maxWeakDamage" : 22, "avgWeakDamage" : 17.5 },
  25 : {"element" : "order","baseDamage" : 7, "minWeakDamage" : 14, "maxWeakDamage" : 23, "avgWeakDamage" : 18.5 },
  26 : {"element" : "dark","baseDamage" : 7, "minWeakDamage" : 14, "maxWeakDamage" : 23, "avgWeakDamage" : 18.5 },
  27 : {"element" : "havoc","baseDamage" : 7, "minWeakDamage" : 14, "maxWeakDamage" : 23, "avgWeakDamage" : 18.5 },
  28 : {"element" : "light","baseDamage" : 7, "minWeakDamage" : 14, "maxWeakDamage" : 23, "avgWeakDamage" : 18.5 },
  29 : {"element" : "havoc","baseDamage" : 8, "minWeakDamage" : 15, "maxWeakDamage" : 24, "avgWeakDamage" : 19.5 },
  30 : {"element" : "lawful","baseDamage" : 9, "minWeakDamage" : 16, "maxWeakDamage" : 25, "avgWeakDamage" : 20.5 },
  31 : {"element" : "havoc","baseDamage" : 9, "minWeakDamage" : 16, "maxWeakDamage" : 25, "avgWeakDamage" : 20.5 },
  32 : {"element" : "almighty","baseDamage" : 10, "minWeakDamage" : 16, "maxWeakDamage" : 26, "avgWeakDamage" : 21 },
}

#sets the "intents" of the bot in discord, essenially telling the server what information it is, and isn't allowed to pull, lets it pull all information
intents = discord.Intents.all()
intents.members = True
#initializes the bot as a discord client with intents specified above
client = discord.Client(intents=intents)

#prints to the console when the bot is ready
@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))
    await client.change_presence(activity=discord.Game('!calcHelp'))

@client.event
async def on_reaction_add(reaction, user):
  if reaction.message.author != client.user:
    return
  elif reaction.message.author == client.user and reaction.emoji == '❌':
    await reaction.message.delete()
  elif reaction.message.content.startswith('$RaidCalculator'):
    await RaidCalculatorUpdate(reaction, user)
  

@client.event
async def on_reaction_remove(reaction, user):
  if reaction.message.author != client.user:
    return
  elif reaction.message.content.startswith('$RaidCalculator'):
    await RaidCalculatorUpdate(reaction, user)



async def RaidCalculatorUpdate(reaction, user):    
  botMsg = reaction.message.content
  botMsg = str.lower(botMsg)
  botMsgSplit =  botMsg.split()
  reactionList = reaction.message.reactions
  AvgDamage = 0
  MinDamage = 0
  MaxDamage = 0
  ID = 0
  ID2 = 0
  ID3 = 0
  RAIDERS = 0
  RAIDERS2 = 0
  RAIDERS3 = 0
  OneCritProb = 0
  TwoCritProb = 0
  for subReaction in reactionList:
    if subReaction.emoji == '1️⃣':
      RAIDERS = subReaction.count -1
    if subReaction.emoji == '2️⃣':
      RAIDERS2 = subReaction.count -1
    if subReaction.emoji == '3️⃣':
      RAIDERS3 = subReaction.count -1
  if RAIDERS2 < 0:
    RAIDERS2 = 0
  if RAIDERS3 < 0:
    RAIDERS3 = 0
  if RAIDERS < 0:
    RAIDERS = 0
  if 'id=' in botMsgSplit:
    ID = int(botMsgSplit[botMsgSplit.index("id=")+1])
  if 'id1=' in botMsgSplit:
    ID = int(botMsgSplit[botMsgSplit.index("id1=")+1])
  if 'id2=' in botMsgSplit:
    ID2 = int(botMsgSplit[botMsgSplit.index("id2=")+1])
  if 'id3=' in botMsgSplit:
    ID3 = int(botMsgSplit[botMsgSplit.index("id3=")+1])
  if 'hp=' in botMsgSplit:
    HP = int(botMsgSplit[botMsgSplit.index("hp=")+1])
  if ID2 <= 0 and ID3 <= 0:
    AvgDamage = RAIDERS * ((WeaponDict.get(ID)).get("avgWeakDamage"))
    MinDamage = RAIDERS * ((WeaponDict.get(ID)).get("minWeakDamage"))
    MaxDamage = RAIDERS * ((WeaponDict.get(ID)).get("maxWeakDamage"))
  elif ID2 > 0 and ID3 <= 0:
    AvgDamage = RAIDERS * ((WeaponDict.get(ID)).get("avgWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("avgWeakDamage"))
    MinDamage = RAIDERS * ((WeaponDict.get(ID)).get("minWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("minWeakDamage"))
    MaxDamage = RAIDERS * ((WeaponDict.get(ID)).get("maxWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("maxWeakDamage"))
  elif ID2 > 0 and ID3 > 0:
    AvgDamage = RAIDERS * ((WeaponDict.get(ID)).get("avgWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("avgWeakDamage")) + RAIDERS3 * ((WeaponDict.get(ID3)).get("avgWeakDamage"))
    MinDamage = RAIDERS * ((WeaponDict.get(ID)).get("minWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("minWeakDamage")) + RAIDERS3 * ((WeaponDict.get(ID3)).get("minWeakDamage"))
    MaxDamage = RAIDERS * ((WeaponDict.get(ID)).get("minWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("maxWeakDamage")) + RAIDERS3 * ((WeaponDict.get(ID3)).get("maxWeakDamage"))
  print(AvgDamage)
  print(MinDamage)
  print(MaxDamage)
  CritDamage = ((RAIDERS + RAIDERS2 + RAIDERS3)/100) * critRate * avgCritDamage
  AvgDamageWithCrit = AvgDamage + CritDamage
  testResult = binomtest(1,(RAIDERS + RAIDERS2 + RAIDERS3), (critRate/100) )
  OneCritProb =  testResult.pvalue
  if (RAIDERS + RAIDERS2 + RAIDERS3) > 2:
    testResult = binomtest(2,(RAIDERS + RAIDERS2 + RAIDERS3), (critRate/100) )
    TwoCritProb = testResult.pvalue
  if ID2 > 0 and ID3 > 0:
    await reaction.message.edit(content = "$RaidCalculator \n\nID1= " + str(ID)+" ID2= "+str(ID2)+" ID3= "+str(ID3)+"\n\nBoss HP= "+str(HP)+ "\n\nAverage Damage = "+ str(AvgDamage)+"\nAverage Damage with crit = "+str(AvgDamageWithCrit)+"\n \nMinimum Damage = "+str(MinDamage)+ "\nMaxDamage = "+str(MaxDamage)+"\n\nOne Crit Probability = "+str((OneCritProb*100))+"% \nTwo Crit Probability = "+str((TwoCritProb*100))+"%")
  elif ID2 > 0 and ID3 <= 0:
    await reaction.message.edit(content = "$RaidCalculator \n\nID1= " + str(ID)+" ID2= "+str(ID2)+"\n\nBoss HP= "+str(HP)+"\n\nAverage Damage = "+ str(AvgDamage)+"\nAverage Damage with crit = "+str(AvgDamageWithCrit)+"\n \nMinimum Damage = "+str(MinDamage)+ "\nMaxDamage = "+str(MaxDamage)+"\n\nOne Crit Probability = "+str((OneCritProb*100))+"% \nTwo Crit Probability = "+str((TwoCritProb*100))+"%")
  else:
    await reaction.message.edit(content = "$RaidCalculator \n\nID= " + str(ID)+"\n\nBoss HP= "+str(HP)+"\n\nAverage Damage = "+ str(AvgDamage)+"\nAverage Damage with crit = "+str(AvgDamageWithCrit)+"\n \nMinimum Damage = "+str(MinDamage)+ "\nMaxDamage = "+str(MaxDamage)+"\n\nOne Crit Probability = "+str((OneCritProb*100))+"% \nTwo Crit Probability = "+str((TwoCritProb*100))+"%")
    
  if AvgDamage > HP and HP > 0:
    await reaction.message.channel.send("Average damage is greater than Boss HP!")
  elif AvgDamageWithCrit > HP and HP > 0:
    await reaction.message.channel.send("Average damage with a crit is greater than Boss HP!")

    


@client.event
async def on_message(message):
    guild = message.guild
    # channel = discord.utils.get(guild.text_channels, name="Name of channel")
    print(message.channel.name)
    #if message.author == client.user:
    #    return
    #takes the content of the message the bot recieved and puts it in the msg string
    msg = message.content
    #makes the message lowercase
    msg = str.lower(msg)
    print(msg)
    #also creates a "message split" so that each word is turned into a sequential entry in a list, important when we want to check level and rank
    msgSplit = msg.split()
    print(msgSplit)

    if message.content.startswith('!calchelp'):
      await message.channel.send("Message format: \n!calculate ID (weapon number) ID2 (second weapon ID, omit ID2 if not using a second weapon) HP (Boss HP, omit if not using boss hp) RAIDERS (no of raiders ,if using raiders), RAIDERS2 (raiders using second weapon) (Element) \nnote: currently the bot assumes that the boss is weak, this may be improved upon as more data is gathered in the future")
    
    if message.content.startswith('!calculate'):
      ID = 0
      HP = 0
      element = ""
      stat = ""
      ID2 = 0
      ID3 = 0
      RAIDERS = 0
      RAIDERS2 = 0
      RAIDERS3 = 0
      AvgDamage = 0
      AvgDamageWithCrit = 0
      MinDamage = 0
      MaxDamage = 0
      CritDamage = 0
      OneCritProb = 0
      TwoCritProb = 0
      if 'id' in msgSplit:
        ID = int(msgSplit[msgSplit.index("id")+1])
      if 'id2' in msgSplit:
        ID2 = int(msgSplit[msgSplit.index("id2")+1])
      if 'id3' in msgSplit:
        ID3 = int(msgSplit[msgSplit.index("id3")+1])
      if 'hp' in msgSplit:
        HP = int(msgSplit[msgSplit.index("hp")+1])
      if 'raiders' in msgSplit:
        RAIDERS = int(msgSplit[msgSplit.index("raiders")+1])
      if 'raiders2' in msgSplit:
        RAIDERS2 = int(msgSplit[msgSplit.index("raiders2")+1])
      if 'raiders3' in msgSplit:
        RAIDERS3 = int(msgSplit[msgSplit.index("raiders3")+1])
      if 'weak' in msgSplit:
        stat = 'weak'
      if 'resist' in msgSplit:
        stat = 'resist'
      if 'element' in msgSplit:
        element = str(msgSplit[msgSplit.index('element')+1])
      print('ID is: ',ID,' Hp is: ',HP,' stat is: ',stat,' element is: ',element)
      if HP <= 0 and RAIDERS <= 0:
        await message.channel.send("Must specify HP or number of raiders ")
      if ID <= 0 and element == "":
        await message.channel.send("Must specify ID or element")
      if ID == 0 and element != "":
        dmgRef = 1
        for Weap in WeaponDict:
          if (WeaponDict.get(Weap)).get("element") == element:
            if (WeaponDict.get(Weap)).get("avgWeakDamage") > dmgRef:
              dmgRef = (WeaponDict.get(Weap)).get("avgWeakDamage")
              ID = Weap
      if ID > 0:
        if RAIDERS != 0:
          if ID2 <= 0 and ID3 <= 0:
            AvgDamage = RAIDERS * ((WeaponDict.get(ID)).get("avgWeakDamage"))
            MinDamage = RAIDERS * ((WeaponDict.get(ID)).get("minWeakDamage"))
            MaxDamage = RAIDERS * ((WeaponDict.get(ID)).get("maxWeakDamage"))
          elif ID2 > 0 and ID3 <= 0:
            AvgDamage = RAIDERS * ((WeaponDict.get(ID)).get("avgWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("avgWeakDamage"))
            MinDamage = RAIDERS * ((WeaponDict.get(ID)).get("minWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("minWeakDamage"))
            MaxDamage = RAIDERS * ((WeaponDict.get(ID)).get("maxWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("maxWeakDamage"))
          elif ID2 > 0 and ID3 > 0:
            AvgDamage = RAIDERS * ((WeaponDict.get(ID)).get("avgWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("avgWeakDamage")) + RAIDERS3 * ((WeaponDict.get(ID3)).get("avgWeakDamage"))
            MinDamage = RAIDERS * ((WeaponDict.get(ID)).get("minWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("minWeakDamage")) + RAIDERS3 * ((WeaponDict.get(ID3)).get("minWeakDamage"))
            MaxDamage = RAIDERS * ((WeaponDict.get(ID)).get("minWeakDamage")) + RAIDERS2 * ((WeaponDict.get(ID2)).get("maxWeakDamage")) + RAIDERS3 * ((WeaponDict.get(ID3)).get("maxWeakDamage"))
          print(AvgDamage)
          print(MinDamage)
          print(MaxDamage)
          CritDamage = ((RAIDERS + RAIDERS2 + RAIDERS3)/100) * critRate * avgCritDamage
          AvgDamageWithCrit = AvgDamage + CritDamage
          testResult = binomtest(1,(RAIDERS + RAIDERS2 + RAIDERS3), (critRate/100) )
          OneCritProb =  testResult.pvalue
          testResult = binomtest(2,(RAIDERS + RAIDERS2 + RAIDERS3), (critRate/100) )
          TwoCritProb = testResult.pvalue
          if ID2 > 0 and ID3 > 0:
            await message.channel.send("Using ID "+ str(ID) +","+str(ID2)+","+str(ID3)+ " with " + str(RAIDERS+RAIDERS2+RAIDERS3) + " raiders: \nAverage Damage = "+ str(AvgDamage)+"\nAverage Damage with crit = "+str(AvgDamageWithCrit)+"\n \nMinimum Damage = "+str(MinDamage)+ "\nMaxDamage = "+str(MaxDamage)+"\n\nOne Crit Probability = "+str((OneCritProb*100))+"% \nTwo Crit Probability = "+str((TwoCritProb*100))+"%" )
          elif ID2 > 0 and ID3 <= 0:
            await message.channel.send("Using ID "+ str(ID) +","+str(ID2)+ " with " + str(RAIDERS+RAIDERS2) + " raiders: \nAverage Damage = "+ str(AvgDamage)+"\nAverage Damage with crit = "+str(AvgDamageWithCrit)+"\n \nMinimum Damage = "+str(MinDamage)+ "\nMaxDamage = "+str(MaxDamage)+"\n\nOne Crit Probability = "+str((OneCritProb*100))+"% \nTwo Crit Probability = "+str((TwoCritProb*100))+"%" )
          elif ID2 <= 0 and ID3 <= 0:
            await message.channel.send("Using ID "+ str(ID) + " with " + str(RAIDERS) + " raiders: \nAverage Damage = "+ str(AvgDamage)+"\nAverage Damage with crit = "+str(AvgDamageWithCrit)+"\n \nMinimum Damage = "+str(MinDamage)+ "\nMaxDamage = "+str(MaxDamage)+"\n\nOne Crit Probability = "+str((OneCritProb*100))+"% \nTwo Crit Probability = "+str((TwoCritProb*100))+"%" )

        elif RAIDERS <= 0 and HP >= 0:
          AvgRaiders = 0
          MinRaiders = 0
          MaxRaiders = 0
          RaidersWithCrit = 0
          AvgRaiders = math.ceil(HP/(WeaponDict.get(ID)).get("avgWeakDamage"))
          MinRaiders = math.ceil(HP/(WeaponDict.get(ID)).get("minWeakDamage"))
          MaxRaiders = math.ceil(HP/(WeaponDict.get(ID)).get("maxWeakDamage"))
          CritDamage = ((AvgRaiders)/100) * critRate * avgCritDamage
          print("Critical damage="+str(CritDamage))
          RaidersWithCrit = math.ceil(((HP-CritDamage)/((WeaponDict.get(ID)).get("avgWeakDamage"))))
          testResult = binomtest(1,(AvgRaiders), (critRate/100) )
          OneCritProb =  testResult.pvalue
          testResult = binomtest(2,(AvgRaiders), (critRate/100) )
          TwoCritProb = testResult.pvalue
          await message.channel.send("Using ID "+ str(ID) +" with "+str(HP)+" boss HP :\nRaiders required with average Damage = "+ str(AvgRaiders)+"\nRaiders required with average damage and crit = "+str(RaidersWithCrit)+"\n \nRaiders required at minimum damage = "+str(MinRaiders)+ "\nRaiders required at maximum damage = "+str(MaxRaiders)+"\n\nOne Crit Probability = "+str((OneCritProb*100))+"% \nTwo Crit Probability = "+str((TwoCritProb*100))+"%")

    if message.content.startswith('!raidcalc'):
      ID = 0
      ID2 = 0
      ID3 = 0
      HP = 0
      if 'id' in msgSplit:
        ID = int(msgSplit[msgSplit.index("id")+1])
      if 'id1' in msgSplit:
        ID = int(msgSplit[msgSplit.index("id1")+1])
      if 'id2' in msgSplit:
        ID2 = int(msgSplit[msgSplit.index("id2")+1])
      if 'id3' in msgSplit:
        ID3 = int(msgSplit[msgSplit.index("id3")+1])
      if 'hp' in msgSplit:
        HP = int(msgSplit[msgSplit.index("hp")+1])
      if ID <= 0:
       await message.channel.send("please specify an ID to use!")
      if ID2 == 0 and ID3 == 0:
        botMsg = await message.channel.send("$RaidCalculator \n\nID= " + str(ID)+"\n\nBoss HP= "+str(HP))
        await botMsg.add_reaction('1️⃣')
      elif ID2 != 0 and ID3 == 0:
        botMsg = await message.channel.send("$RaidCalculator \n\nID1= " + str(ID)+" ID2= "+str(ID2)+"\n\nBoss HP= "+str(HP))
        await botMsg.add_reaction('1️⃣')
        await botMsg.add_reaction('2️⃣')
      elif ID2 !=0 and ID3 != 0:
        botMsg = await message.channel.send("$RaidCalculator \n\nID1= " + str(ID)+" ID2= "+str(ID2)+" ID3= "+str(ID3)+"\n\nBoss HP= "+str(HP))
        await botMsg.add_reaction('1️⃣')
        await botMsg.add_reaction('2️⃣')
        await botMsg.add_reaction('3️⃣')
         
    if message.content.startswith('!calcadd'):
      IDKey = int(msgSplit[msgSplit.index("id")+1])
      baseDamage = int(msgSplit[msgSplit.index("basedamage")+1])
      minWeakDamage = int(msgSplit[msgSplit.index("minweakdamage")+1])
      maxWeakDamage = int(msgSplit[msgSplit.index("maxweakdamage")+1])
      element = str(msgSplit[msgSplit.index("element")+1])
      WeaponDict[IDKey] = {"element" : element,"baseDamage" : baseDamage, "minWeakDamage" : minWeakDamage, "maxWeakDamage" : maxWeakDamage, "avgWeakDamage" : ((minWeakDamage+maxWeakDamage)/2)}

      




keep_alive.keep_alive()

#executes all the above with the bot's discord verification token, which is in an environment variable to ensure the bot stays secure and does not produce any security vulnerabilities. Even if someone manages to read the code, they will not be able to read the token as it is present only as TOKEN throughout the script, and the actual alphanumeric sequence is hidden
client.run(os.getenv('TOKEN'))
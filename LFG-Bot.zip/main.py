#imports discord and os libraries
import discord
import os
from discord.ext import commands
from discord.ext.commands import bot
import asyncio
import datetime
import flask

import keep_alive

#defines all criteria as strings and indiscriminative, I wrote ndsc because writing indiscriminative every time would be tedious, indiscriminative means that the bot won't filter for these criteria
Criteria1Comms = "ndsc"
Criteria2Sweat = "ndsc"
Criteria3Interceptor = "ndsc"
Criteria3Fighter = "ndsc"
Criteria3Bomber = "ndsc"
Criteria3Support = "ndsc"
Criteria4Rank = "ndsc"
Criteria5Level = "ndsc"
Criteria6Time = "ndsc"
Criteria7Online = "ndsc"
#the ranks and level brackets in order, important for when we want to check if a member of the server has a rank/level higher than the minimum rank/level set by the user
RankList = ['maverick','hotshot','hero','valiant','legend','ace']
LevelList = ['<20','<40','<60','<80','<100','>100']

#sets the "intents" of the bot in discord, essenially telling the server what information it is, and isn't allowed to pull, lets it pull all information
intents = discord.Intents.all()
intents.members = True
#initializes the bot as a discord client with intents specified above
client = discord.Client(intents=intents)

#prints to the console when the bot is ready
@client.event
async def on_ready():
    print('We have logged in as {0.user}'.format(client))
    await client.change_presence(activity=discord.Game('$help'))

#client event of recieving a message, but returns when it's the bot's message
@client.event
async def on_message(message):
    guild = message.guild
    # channel = discord.utils.get(guild.text_channels, name="Name of channel")
    print(message.channel.name)
    if message.author == client.user:
        return
    #checks if the message recieved is in the looking for group channel, and if it's not the bot simply returns and does nothing, printing to the console that the message is in the "incorrect" channel and will not read it
    if str(message.channel.name) != "lfg" and str(message.channel.name) != "looking-for-group":
        print("incorrect channel!")
        return

    #takes the content of the message the bot recieved and puts it in the msg string
    msg = message.content
    #replaces all commas with spaces so that when the message is split commas are not included with the words
    msg = msg.replace(',',' ')
    msg = msg.replace('"',' ')
    msg = msg.replace("'",' ')
    msg = msg.replace('"',' ')
    msg = msg.replace("(",' ')
    msg = msg.replace('"',' ')
    msg = msg.replace(")",' ')
    msg = msg.replace("*",' ')
    msg = msg.replace("_",' ')
    msg = msg.replace("~",' ')
    msg = msg.replace("`",' ')
    msg = msg.replace("|",' ')
    msg = msg.replace(":",' ') 
    #makes all of the message lowercase because we don't want the user criteria inputs to be case sensitive 
    msg = str.lower(msg)
    print(msg)
    #also creates a "message split" so that each word is turned into a sequential entry in a list, important when we want to check level and rank
    msgSplit = msg.split()
    print(msgSplit)

    if message.content.startswith('$help'):
      #if the message starts with $help it prints out a set of instructions and notes as discord messages for how to use the bot
      await message.channel.send("Message format: $ping communicative, ranked/casual, role(s),minimum rank (minimum rank), minimum level (minimum level number),online (only pings those who are currently online)")
      await message.channel.send("the bot will sort for members with the lfg role that match your criteria and ping them")
      await message.channel.send("Example: $ping communicative,casual,support,bomber,rank hotshot,level 23,online")
      await message.channel.send("Note: order does not matter, so type in any order you want, if you don't want to sort by any of the criteria just don't type them, and the bot is not case sensitive, if you are going to play in a bit then you can just write at what time at the end of the message")
      await message.channel.send("use $find to do the same thing but without pinging the users")
    #checks if the message starts with $ping which is the command for the bot, and will print this to the console
    if message.content.startswith('$ping'):
      #sends a message in chat indicating to the user that it has begun the sorting process and prints to the console that the bot has been "pinged" and has begun reading the message for criteria keywords
      await message.channel.send('Sorting - (if this takes too long then the input may be incorrect)')
      print('pinged')
      #resets criteria
      Criteria1Comms = "ndsc"
      Criteria2Sweat = "ndsc"
      Criteria3Interceptor = "ndsc"
      Criteria3Fighter = "ndsc"
      Criteria3Bomber = "ndsc"
      Criteria3Support = "ndsc"
      Criteria4Rank = "ndsc"
      Criteria5Level = "ndsc"
      Criteria5LevelHolder = 0
      Criteria6Time = "ndsc"
      Criteria7Online = "ndsc"
      memberlist = []
      #uses if loops to see if the criteria are in the message and sets criteria variables to the appropriate strings
      if 'communicative' in msg:
        Criteria1Comms = "Communicative"
      print('Criteria 1 Comms =', Criteria1Comms)
      if 'ranked' in msg:
        Criteria2Sweat = "Ranked"
      print('Criteria 2 Sweat =', Criteria2Sweat)
      if 'casual' in msg:
        Criteria2Sweat = "Casual"
      print('Criteria 2 Sweat =', Criteria2Sweat)
      #in case the users decide that they don't want to sort by casual/ranked and think that they do it by writing both
      if 'casual' in msg and 'ranked' in msg:
        Criteria2Sweat = "ndsc"
      print('Criteria 2 Sweat=', Criteria2Sweat)
      #checks what role(s) the user is looking for in teammates
      if 'interceptor' in msg:
        Criteria3Interceptor = "dsc"
      print('Criteria 3 Interceptor =', Criteria3Interceptor)
      if 'fighter' in msg:
        Criteria3Fighter = "dsc"
      print('Criteria 3 fighter =', Criteria3Fighter)
      if 'bomber' in msg:
        Criteria3Bomber = "dsc"
      print('Criteria 3 Bomber =', Criteria3Bomber)
      if 'support' in msg:
        Criteria3Support = "dsc"
      print('Criteria 3 Support =', Criteria3Support)
      if 'level' in msgSplit:
        #this is some pretty nifty code, what I'm doing here is splitting the message into a list with every word as a list item, then looking for the index of the word level, and finds the word right after that which will of course be the level number
        Criteria5LevelHolder = int(msgSplit[msgSplit.index("level")+1])
        print('Criteria 5 Level =',Criteria5LevelHolder)
        #sets the 'bracket' that the user is looking for in the minimum level, the brackets match up to the names of the roles users take, also allows for some adjustment on the minimum level so that the user will find someone just around the minimum level they were looking for, ensuring that there's some wiggle room
        if Criteria5LevelHolder <20:
          Criteria5Level = '<20'
        if Criteria5LevelHolder <40 and Criteria5LevelHolder >=20:
          Criteria5Level = '<40'
        if Criteria5LevelHolder <60 and Criteria5LevelHolder >=40:
          Criteria5Level = '<60'
        if Criteria5LevelHolder <80 and Criteria5LevelHolder >=60:
          Criteria5Level = '<80'
        if Criteria5LevelHolder <100 and Criteria5LevelHolder >=80:
          Criteria5Level = '<100'
        if Criteria5LevelHolder >=100:
          Criteria5Level = '>100'
      print('Criteria 5 Level Bracket =',Criteria5Level)
      #sets the minimum rank depending on which of the rank keywords is in the message
      if 'maverick' in msg:
        Criteria4Rank = 'maverick'
        print('Criteria 4 rank =',Criteria4Rank)
      if 'hotshot' in msg or 'hot shot' in msg:
        Criteria4Rank = 'hotshot'
      print('Criteria 4 rank =',Criteria4Rank)
      if 'hero' in msg:
        Criteria4Rank = 'hero'
      print('Criteria 4 rank =',Criteria4Rank)
      if 'valiant' in msg:
        Criteria4Rank = 'valiant'
      print('Criteria 4 rank =',Criteria4Rank)
      if 'legend' in msg:
        Criteria4Rank = 'legend'
      print('Criteria 4 rank =',Criteria4Rank)
      if 'ace' in msg:
        Criteria4Rank = 'ace'
      print('Criteria 4 rank =',Criteria4Rank)
      
      #some unused code for looking at what time the user wants to play, but was commented out as this feature was cut
      # if 'min' in msgSplit:
      #   #basically doing the same thing I did back for level but now for time, and also 3 times over in case of user error
      #   Criteria6Time = int(msgSplit[msgSplit.index('min')-1])
      # print('Criteria 6 time =', Criteria6Time)
      # if 'mins' in msgSplit:
      #   #basically doing the same thing I did back for level but now for time, and also 3 times over in case of user error
      #   Criteria6Time = int(msgSplit[msgSplit.index('mins')-1])
      # print('Criteria 6 time =', Criteria6Time)
      # if 'minutes' in msgSplit:
      #   #basically doing the same thing I did back for level but now for time, and also 3 times over in case of user error
      #   Criteria6Time = int(msgSplit[msgSplit.index('minutes')-1])
      # print('Criteria 6 time =', Criteria6Time)

      #code to check if the user only wants to ping members who are online
      if 'online' in msg:
        Criteria7Online = 'online'
      print('Criteria 7 Online =', Criteria7Online)


      #The function that checks every role a member has to see if they have a role matching the input
      def checkrole(roleName, member):
        for role in member.roles:
          if (role.name == roleName):
            return True
        return False
      
      #to check the index of the rank/level that a member has in the ranklist from earlier
      def checkRank(member,list):
        for role in member.roles:
          roleName = role.name.lower()
          print("role is", role.name)
          for rank in list:
            print('rank is', rank)
            if roleName == rank:
              print('rank found!')
              return list.index(rank)
        return False

      #for loop cycles through every member in the server
      for member in guild.members:
        #checks if the first criteria (communiation) is indiscriminate or if the member has the communication role, continues to next member if they don't and continues to the next criteria if they do
        if Criteria1Comms == "ndsc" or checkrole("Communication", member) == True:
          #checks if the ranked/casual criteria is indiscriminate or if the member has the ranked/casual role depending on which the user specified, continues to next member if they don't and continues to the next criteria if they do
          if ((Criteria2Sweat == "ndsc") or (Criteria2Sweat == 'Ranked' and checkrole('Ranked', member) == True) or (Criteria2Sweat == 'Casual' and checkrole('Casual', member) == True)):
            #checks if all of the roles someone can play in the game (fighter,support,etc.) are all indiscriminate, passes to next criteria if they are. If not it checks if the member has any one of the roles that the user specified, if not, cycles to the next member
            if ( Criteria3Interceptor == "ndsc" and Criteria3Fighter == "ndsc" and Criteria3Support == "ndsc" and Criteria3Bomber == "ndsc") or (Criteria3Interceptor == "dsc" and checkrole("Interceptor",member) == True) or (Criteria3Fighter == "dsc" and checkrole("Fighter",member) == True) or(Criteria3Bomber == "dsc" and checkrole("Bomber",member) == True) or (Criteria3Support == "dsc" and checkrole("Support",member) == True):
              #checks if the rank criteria is indiscriminate and goes to the next criteria if it is. If not, then it checks if the member has a rank higher than the rank the user specified (by comparing where in the ranklist the member's rank is vs the user specified rank). If the member passes it moves on to the next criteria, if not it exits the condition and moves to the next member
              if (Criteria4Rank == "ndsc" or Criteria4Rank == "maverick" or (checkRank(member,RankList) >= RankList.index(Criteria4Rank))):
                #does the same thing that we just did for rank but for the level bracket the user specified vs the level bracket the member is in
                if(Criteria5Level == "ndsc" or Criteria5Level == "<20" or (checkRank(member,LevelList) >= LevelList.index(Criteria5Level))):
                  #prints the status of every member as well as the type of the status, originally for troubleshooting purposes but now it's just good information to have to ensure the bot is functioning correctly
                  print(member.status)
                  print(type(member.status))
                  #checks if the "online" criteria is indiscriminate or if the member is online (as if the online criteria is not indiscriminate the only alternative is that the user wants members they ping to be online). If it fails either of the conditions it exits and moves to repeating the if conditions for the next member, if not it moves to the last condition
                  if (Criteria7Online == "ndsc") or (str(member.status) == "online"):
                    #checks if the member has the lfg role which indicates they want to be pinged by the lfg bot if an invite comes up
                    if checkrole("LFG", member) == True or checkrole("Lfg", member) == True or checkrole("lfg", member) == True:
                      #checks if the member has the "OnlyOnline" role, which means the member only wants to be pinged if they are online, if they don't it moves on to ping them, but if they do it checks if they are online, if they aren't online it exits and moves to the next member
                        if (checkrole("OnlyOnline",member) == False) or ((checkrole("OnlyOnline",member) == True) and (str(member.status) == "online")):
                          #prints to the console that the bot is pinging the member (once they've passed all criteria)
                          print ("Sending ping to member", member)
                          #sends a message in chat that also 'mentions' the member and pings them with an audible sound and notification that there is a ping on the new republic server, in $find this is replaced by simply mentioning the member's username with ('found{}'.format(member))
                          await message.channel.send('Pinging {}'.format(member.mention))
                          #adds the member to the memberlist, important to see if it actually has any members in the next bit of code
                          memberlist.append(member)
                        #all the elses for the previous conditions that tell the bot to go to the next member if this member fails any of the conditions
                        else:
                          continue
                    else:
                      continue
                  else:
                    continue
                else:
                  continue
              else:
                continue
            else:
              continue
          else:
            continue
        else:
          continue
      #checks if the memberlist has any members in it, if the list does not have any members then that means the bot could not find any matching the criteria on the server and it will send a message in chat indicating that no members were found
      if not memberlist:
        await message.channel.send("No members matching criteria found")
      else:
        #if members could be found and pinged the bot will send a message in chat reading "RSVP here" underneath which two reaction buttons will be created with the white check mark and red x symbols, if a user hovers over the buttons they will be able to see all members, this entire else block of code is not present in $find
        messageRSVP = await message.channel.send("RSVP here")
        #creates the reaction buttons using the unicode for the white check mark and red x
        await messageRSVP.add_reaction("\u2705")
        await messageRSVP.add_reaction("\u274c")

#exact same code and function as the above ping command with the only difference being that it sends messages to the chat with the usernames of members instead of pinging them, and never sends the RSVP message and reaction buttons
    if message.content.startswith('$find'):
      #sends a message in chat indicating to the user that it has begun the sorting process and prints to the console that the bot has been "pinged" and has begun reading the message for criteria keywords
      await message.channel.send('Sorting - (if this takes too long then the input may be incorrect)')
      print('pinged')
      #resets criteria
      Criteria1Comms = "ndsc"
      Criteria2Sweat = "ndsc"
      Criteria3Interceptor = "ndsc"
      Criteria3Fighter = "ndsc"
      Criteria3Bomber = "ndsc"
      Criteria3Support = "ndsc"
      Criteria4Rank = "ndsc"
      Criteria5Level = "ndsc"
      Criteria5LevelHolder = 0
      Criteria6Time = "ndsc"
      Criteria7Online = "ndsc"
      memberlist = []
      #uses if loops to see if the criteria are in the message and sets criteria variables to the appropriate strings
      if 'communicative' in msg:
        Criteria1Comms = "Communicative"
      print('Criteria 1 Comms =', Criteria1Comms)
      if 'ranked' in msg:
        Criteria2Sweat = "Ranked"
      print('Criteria 2 Sweat =', Criteria2Sweat)
      if 'casual' in msg:
        Criteria2Sweat = "Casual"
      print('Criteria 2 Sweat =', Criteria2Sweat)
      #in case the users decide that they don't want to sort by casual/ranked and think that they do it by writing both
      if 'casual' in msg and 'ranked' in msg:
        Criteria2Sweat = "ndsc"
      print('Criteria 2 Sweat=', Criteria2Sweat)
      #checks what role(s) the user is looking for in teammates
      if 'interceptor' in msg:
        Criteria3Interceptor = "dsc"
      print('Criteria 3 Interceptor =', Criteria3Interceptor)
      if 'fighter' in msg:
        Criteria3Fighter = "dsc"
      print('Criteria 3 fighter =', Criteria3Fighter)
      if 'bomber' in msg:
        Criteria3Bomber = "dsc"
      print('Criteria 3 Bomber =', Criteria3Bomber)
      if 'support' in msg:
        Criteria3Support = "dsc"
      print('Criteria 3 Support =', Criteria3Support)
      if 'level' in msgSplit:
        #this is some pretty nifty code, what I'm doing here is splitting the message into a list with every word as a list item, then looking for the index of the word level, and finds the word right after that which will of course be the level number
        Criteria5LevelHolder = int(msgSplit[msgSplit.index("level")+1])
        print('Criteria 5 Level =',Criteria5LevelHolder)
        #sets the 'bracket' that the user is looking for in the minimum level, the brackets match up to the names of the roles users take, also allows for some adjustment on the minimum level so that the user will find someone just around the minimum level they were looking for, ensuring that there's some wiggle room
        if Criteria5LevelHolder <20:
          Criteria5Level = '<20'
        if Criteria5LevelHolder <40 and Criteria5LevelHolder >=20:
          Criteria5Level = '<40'
        if Criteria5LevelHolder <60 and Criteria5LevelHolder >=40:
          Criteria5Level = '<60'
        if Criteria5LevelHolder <80 and Criteria5LevelHolder >=60:
          Criteria5Level = '<80'
        if Criteria5LevelHolder <100 and Criteria5LevelHolder >=80:
          Criteria5Level = '<100'
        if Criteria5LevelHolder >=100:
          Criteria5Level = '>100'
      print('Criteria 5 Level Bracket =',Criteria5Level)
      #sets the minimum rank depending on which of the rank keywords is in the message
      if 'maverick' in msg:
        Criteria4Rank = 'maverick'
        print('Criteria 4 rank =',Criteria4Rank)
      if 'hotshot' or 'hot shot' in msg:
        Criteria4Rank = 'hotshot'
      print('Criteria 4 rank =',Criteria4Rank)
      if 'hero' in msg:
        Criteria4Rank = 'hero'
      print('Criteria 4 rank =',Criteria4Rank)
      if 'valiant' in msg:
        Criteria4Rank = 'valiant'
      print('Criteria 4 rank =',Criteria4Rank)
      if 'legend' in msg:
        Criteria4Rank = 'legend'
      print('Criteria 4 rank =',Criteria4Rank)
      if 'ace' in msg:
        Criteria4Rank = 'ace'
      print('Criteria 4 rank =',Criteria4Rank)
      
      #some unused code for looking at what time the user wants to play, but was commented out as this feature was cut
      # if 'min' in msgSplit:
      #   #basically doing the same thing I did back for level but now for time, and also 3 times over in case of user error
      #   Criteria6Time = int(msgSplit[msgSplit.index('min')-1])
      # print('Criteria 6 time =', Criteria6Time)
      # if 'mins' in msgSplit:
      #   #basically doing the same thing I did back for level but now for time, and also 3 times over in case of user error
      #   Criteria6Time = int(msgSplit[msgSplit.index('mins')-1])
      # print('Criteria 6 time =', Criteria6Time)
      # if 'minutes' in msgSplit:
      #   #basically doing the same thing I did back for level but now for time, and also 3 times over in case of user error
      #   Criteria6Time = int(msgSplit[msgSplit.index('minutes')-1])
      # print('Criteria 6 time =', Criteria6Time)

      #code to check if the user only wants to ping members who are online
      if 'online' in msg:
        Criteria7Online = 'online'
      print('Criteria 7 Online =', Criteria7Online)


      #The function that checks every role a member has to see if they have a role matching the input
      def checkrole(roleName, member):
        for role in member.roles:
          if (role.name == roleName):
            return True
        return False
      
      #to check the index of the rank/level that a member has in the ranklist from earlier
      def checkRank(member,list):
        for role in member.roles:
          roleName = role.name.lower()
          print("role is", role.name)
          for rank in list:
            print('rank is', rank)
            if roleName == rank:
              print('rank found!')
              return list.index(rank)
        return False

      #for loop cycles through every member in the server
      for member in guild.members:
        #checks if the first criteria (communiation) is indiscriminate or if the member has the communication role, continues to next member if they don't and continues to the next criteria if they do
        if Criteria1Comms == "ndsc" or checkrole("Communication", member) == True:
          #checks if the ranked/casual criteria is indiscriminate or if the member has the ranked/casual role depending on which the user specified, continues to next member if they don't and continues to the next criteria if they do
          if ((Criteria2Sweat == "ndsc") or (Criteria2Sweat == 'Ranked' and checkrole('Ranked', member) == True) or (Criteria2Sweat == 'Casual' and checkrole('Casual', member) == True)):
            #checks if all of the roles someone can play in the game (fighter,support,etc.) are all indiscriminate, passes to next criteria if they are. If not it checks if the member has any one of the roles that the user specified, if not, cycles to the next member
            if ( Criteria3Interceptor == "ndsc" and Criteria3Fighter == "ndsc" and Criteria3Support == "ndsc" and Criteria3Bomber == "ndsc") or (Criteria3Interceptor == "dsc" and checkrole("Interceptor",member) == True) or (Criteria3Fighter == "dsc" and checkrole("Fighter",member) == True) or(Criteria3Bomber == "dsc" and checkrole("Bomber",member) == True) or (Criteria3Support == "dsc" and checkrole("Support",member) == True):
              #checks if the rank criteria is indiscriminate and goes to the next criteria if it is. If not, then it checks if the member has a rank higher than the rank the user specified (by comparing where in the ranklist the member's rank is vs the user specified rank). If the member passes it moves on to the next criteria, if not it exits the condition and moves to the next member
              if (Criteria4Rank == "ndsc" or Criteria4Rank == "maverick" or (checkRank(member,RankList) >= RankList.index(Criteria4Rank))):
                #does the same thing that we just did for rank but for the level bracket the user specified vs the level bracket the member is in
                if(Criteria5Level == "ndsc" or Criteria5Level == "<20" or (checkRank(member,LevelList) >= LevelList.index(Criteria5Level))):
                  #prints the status of every member as well as the type of the status, originally for troubleshooting purposes but now it's just good information to have to ensure the bot is functioning correctly
                  print(member.status)
                  print(type(member.status))
                  #prints to the console that the bot is pinging the member (once they've passed all criteria)
                  print ("Sending ping to member", member)
                  #sent a message in chat that also 'mentions' the member and pings them with an audible sound and notification that there is a ping on the new republic server in $ping, in $find this has been replaced by simply mentioning the member's username with ('found{}'.format(member))
                  await message.channel.send('Found {}'.format(member))
                  #adds the member to the memberlist, important to see if it actually has any members in the next bit of code
                  memberlist.append(member)
                  #all the elses for the previous conditions that tell the bot to go to the next member if this member fails any of the conditions
                else:
                  continue
              else:
                continue
            else:
              continue
          else:
            continue
        else:
          continue
      #checks if the memberlist has any members in it, if the list does not have any members then that means the bot could not find any matching the criteria on the server and it will send a message in chat indicating that no members were found
      if not memberlist:
        await message.channel.send("No members matching criteria found")

keep_alive.keep_alive()

#executes all the above with the bot's discord verification token, which is in an environment variable to ensure the bot stays secure and does not produce any security vulnerabilities. Even if someone manages to read the code, they will not be able to read the token as it is present only as TOKEN throughout the script, and the actual alphanumeric sequence is hidden
client.run(os.getenv('TOKEN'))